'use strict';
// =====================================================================
//  語音房前端：WebRTC 多人語音（網狀連線）+ 主辦方螢幕分享
// =====================================================================
const $ = (s) => document.querySelector(s);
const rid = () => Array.from(crypto.getRandomValues(new Uint8Array(10)), (b) => (b % 36).toString(36)).join('');
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch { } },
};

// ---- 連結參數 ----
const qs = new URLSearchParams(location.search);
const hostToken = qs.get('host') || '';
let roomKey = qs.get('k') || '';
if (roomKey) store.set('roomKey', roomKey); else if (!hostToken) roomKey = store.get('roomKey', '');

// ---- 狀態 ----
const myId = rid();
let myName = '';
let config = null;
let audioCtx = null, masterGain = null;
let micStream = null, micAnalyser = null;
let micOn = true, deaf = false;
let screenState = { active: false, streamId: null, hostId: null };
let screenStream = null;        // 主辦方自己的螢幕
let remoteScreenStream = null;  // 別人看到的螢幕
let watching = true;
let joined = false, ended = false;
const peers = new Map();

// ---------------------------------------------------------------------
//  初始化
// ---------------------------------------------------------------------
$('#nameInput').value = store.get('name', '');
init();

async function init() {
  try {
    const r = await fetch(`/api/config?k=${encodeURIComponent(roomKey)}&host=${encodeURIComponent(hostToken)}`);
    if (r.status === 403) return showJoinError('這個連結無效或已過期，請跟主辦方要新的連結。', true);
    config = await r.json();
  } catch {
    return showJoinError('連不到伺服器，可能主辦方還沒開，或已經關閉了。', true);
  }
  if (config.isHost) {
    roomKey = config.roomKey;
    $('#joinHint').textContent = '你是主辦方。加入後可以分享螢幕、把連結傳給朋友。';
    setShareUrl(config.shareUrl);
  }
  if (!window.isSecureContext) {
    $('#joinHint').textContent = '⚠️ 這不是 https 連結，瀏覽器不允許用麥克風，你只能「聽」。';
  }
}

function showJoinError(msg, disable) {
  const e = $('#joinError'); e.textContent = msg; e.hidden = false;
  if (disable) $('#joinBtn').disabled = true;
}

$('#nameInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') join(); });
$('#joinBtn').addEventListener('click', join);

// ---------------------------------------------------------------------
//  加入
// ---------------------------------------------------------------------
async function join() {
  if (joined || !config) return;
  $('#joinBtn').disabled = true;
  myName = $('#nameInput').value.trim() || '訪客' + Math.floor(Math.random() * 1000);
  store.set('name', myName);

  // 音訊引擎（必須在使用者點擊後建立）
  audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  await audioCtx.resume().catch(() => { });
  masterGain = audioCtx.createGain();
  masterGain.gain.value = Number(store.get('masterVol', 100)) / 100;
  masterGain.connect(audioCtx.destination);
  $('#masterVol').value = Math.round(masterGain.gain.value * 100);
  $('#masterVolOut').value = $('#masterVol').value + '%';
  audioCtx.onstatechange = checkAudioState;

  // 麥克風
  try {
    micStream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
    });
    micAnalyser = audioCtx.createAnalyser(); micAnalyser.fftSize = 512;
    audioCtx.createMediaStreamSource(micStream).connect(micAnalyser);
  } catch (e) {
    micStream = null; micOn = false;
    toast('沒有取得麥克風，你會以「只聽」模式加入', 4000);
  }

  joined = true;
  $('#joinView').hidden = true;
  $('#roomView').hidden = false;
  if (config.isHost) $('#hostPanel').hidden = false;
  if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) $('#shareBtn').hidden = true;

  renderMe();
  updateControls();
  setupMediaSession();
  connectEvents();
  setInterval(speakingLoop, 150);
}

// ---------------------------------------------------------------------
//  伺服器事件：長輪詢（一般 HTTP 請求，經過 Cloudflare 通道也不會卡住）
// ---------------------------------------------------------------------
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function joinServer() { return api('/api/join', { name: myName, mic: micOn && !!micStream }); }

async function connectEvents() {
  let since = 0, fails = 0, needJoin = true;
  while (!ended) {
    try {
      if (needJoin) { await joinServer(); needJoin = false; since = 0; }
      const r = await fetch(`/api/poll?id=${myId}&k=${encodeURIComponent(roomKey)}&host=${encodeURIComponent(hostToken)}` +
        `&since=${since}&t=${Date.now()}`, { cache: 'no-store' });
      if (r.status === 410) { needJoin = true; continue; } // 伺服器以為我離開了 → 重新加入
      if (r.status === 403) { endCall('連結已失效。', true, '無法連線'); return; }
      if (!r.ok) throw new Error(r.status);
      const { events } = await r.json();
      fails = 0;
      setNetBad(false);
      for (const e of events) {
        since = Math.max(since, e.seq);
        try { handleEvent(e.event, e.data); } catch (err) { console.warn(e.event, err); }
      }
    } catch (err) {
      if (ended) return;
      fails++;
      if (fails >= 3) setNetBad(true);
      await sleep(Math.min(2500, 300 * fails));
    }
  }
}

function setNetBad(bad) {
  if (bad && !netBad) toast('與伺服器的連線不穩，重新連線中…', 3000);
  netBad = bad;
}
let netBad = false;

function handleEvent(type, d) {
  switch (type) {
    case 'welcome': {
      if (d.fresh) for (const id of [...peers.keys()]) removePeer(id); // 重新加入 → 舊連線全部重建
      const ids = new Set(d.peers.map((p) => p.id));
      for (const id of [...peers.keys()]) if (!ids.has(id)) removePeer(id);
      for (const p of d.peers) ensurePeer(p);
      setScreenState(d.screen);
      if (d.shareUrl) setShareUrl(d.shareUrl);
      postStatus();
      break;
    }
    case 'join': ensurePeer(d); toast(`${d.name} 加入了`); break;
    case 'leave': {
      const p = peers.get(d.id); if (p) toast(`${p.info.name} 離開了`);
      removePeer(d.id); break;
    }
    case 'signal': onSignal(d.from, d.data); break;
    case 'status': {
      const p = peers.get(d.id);
      if (p) { Object.assign(p.info, d); updatePeerCard(p); }
      break;
    }
    case 'screen': setScreenState(d); break;
    case 'shareurl': setShareUrl(d.shareUrl); break;
    case 'ended': endCall('主辦方已經結束了這個語音房。'); break;
  }
}

// 依序送出協商訊息（保持順序很重要）
let outbox = [], flushing = false;
function send(to, data) { outbox.push({ to, data }); if (!flushing) flush(); }
async function flush() {
  flushing = true;
  while (outbox.length) {
    const msgs = outbox.splice(0);
    for (let tries = 0; tries < 3; tries++) {
      try { await api('/api/signal', { msgs }); break; } catch { await new Promise((r) => setTimeout(r, 500)); }
    }
  }
  flushing = false;
}
function api(url, body) {
  return fetch(url, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ k: roomKey, host: hostToken, from: myId, ...body }),
  }).then((r) => { if (!r.ok) throw new Error(r.status); return r.json(); });
}
function postStatus() { api('/api/status', { mic: micOn && !!micStream, deaf }).catch(() => { }); }

// ---------------------------------------------------------------------
//  WebRTC：每個人跟每個人各一條連線，用「perfect negotiation」避免衝突
// ---------------------------------------------------------------------
function ensurePeer(info) {
  let p = peers.get(info.id);
  if (p) { Object.assign(p.info, info); updatePeerCard(p); return p; }

  const pc = new RTCPeerConnection({ iceServers: config.iceServers });
  p = {
    id: info.id, info: { ...info }, pc, polite: myId > info.id,
    makingOffer: false, ignoreOffer: false, queue: Promise.resolve(),
    screenSenders: [], stream: null, muted: false,
    gain: audioCtx.createGain(), analyser: audioCtx.createAnalyser(),
  };
  p.analyser.fftSize = 512;
  p.vol = Number(store.get('vol:' + info.name, 100));
  p.gain.gain.value = deaf ? 0 : p.vol / 100;
  p.gain.connect(masterGain);
  peers.set(info.id, p);

  if (micStream) micStream.getTracks().forEach((t) => pc.addTrack(t, micStream));
  else pc.addTransceiver('audio', { direction: 'recvonly' });
  if (screenStream) screenStream.getTracks().forEach((t) => p.screenSenders.push(pc.addTrack(t, screenStream)));

  pc.onnegotiationneeded = async () => {
    try {
      p.makingOffer = true;
      await pc.setLocalDescription();
      send(p.id, { description: pc.localDescription });
    } catch (e) { console.warn('offer', e); } finally { p.makingOffer = false; }
  };
  pc.onicecandidate = ({ candidate }) => { if (candidate) send(p.id, { candidate }); };
  pc.ontrack = (ev) => onTrack(p, ev);
  pc.onconnectionstatechange = () => {
    updatePeerCard(p);
    const st = pc.connectionState;
    if (st === 'connected') p.reported = false;
    // 跟對方的語音斷了 → 請伺服器確認對方是不是已經關掉網頁
    if ((st === 'disconnected' || st === 'failed') && !p.reported) {
      p.reported = true;
      api('/api/peerlost', { id: p.id }).catch(() => { });
    }
    if (st === 'failed') pc.restartIce();
  };

  renderPeerCard(p);
  updateCount();
  return p;
}

function onSignal(from, data) {
  const p = peers.get(from) || ensurePeer({ id: from, name: '…', mic: true });
  p.queue = p.queue.then(async () => {
    const pc = p.pc;
    try {
      if (data.description) {
        const collision = data.description.type === 'offer' && (p.makingOffer || pc.signalingState !== 'stable');
        p.ignoreOffer = !p.polite && collision;
        if (p.ignoreOffer) return;
        await pc.setRemoteDescription(data.description);
        if (data.description.type === 'offer') {
          await pc.setLocalDescription();
          send(from, { description: pc.localDescription });
        }
      } else if (data.candidate) {
        try { await pc.addIceCandidate(data.candidate); } catch (e) { if (!p.ignoreOffer) console.warn('ice', e); }
      }
    } catch (e) { console.warn('signal', e); }
  });
}

function onTrack(p, ev) {
  const stream = ev.streams[0] || new MediaStream([ev.track]);
  const isScreen = ev.track.kind === 'video' || (screenState.active && stream.id === screenState.streamId);
  if (isScreen) { showRemoteScreen(stream); return; }
  if (p.stream === stream) return;
  p.stream = stream;
  // Chrome 的已知問題：遠端串流要先接到一個（靜音的）audio 元素，Web Audio 才會有聲音
  p.sink = new Audio(); p.sink.muted = true; p.sink.srcObject = stream; p.sink.play().catch(() => { });
  p.source = audioCtx.createMediaStreamSource(stream);
  p.source.connect(p.gain);
  p.source.connect(p.analyser);
  checkAudioState();
}

function removePeer(id) {
  const p = peers.get(id); if (!p) return;
  peers.delete(id);
  try { p.pc.close(); } catch { }
  try { p.source && p.source.disconnect(); p.gain.disconnect(); } catch { }
  if (p.sink) p.sink.srcObject = null;
  p.card && p.card.remove();
  if (screenState.hostId === id) setScreenState({ active: false });
  updateCount();
}

// ---------------------------------------------------------------------
//  介面：參與者卡片
// ---------------------------------------------------------------------
const colors = ['#6366f1', '#ec4899', '#14b8a6', '#f59e0b', '#8b5cf6', '#06b6d4', '#ef4444', '#84cc16'];
function colorOf(s) { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0; return colors[h % colors.length]; }

function makeCard(name) {
  const card = $('#personTpl').content.firstElementChild.cloneNode(true);
  const av = card.querySelector('.avatar');
  av.textContent = [...name][0] || '?';
  av.style.background = colorOf(name);
  card.querySelector('.name').textContent = name;
  return card;
}

let meCard = null;
function renderMe() {
  meCard = makeCard(myName);
  meCard.classList.add('me');
  meCard.querySelector('.name').textContent = myName + '（你）' + (config.isHost ? ' 👑' : '');
  meCard.querySelector('.pctl').remove();
  $('#people').prepend(meCard);
  updateMe();
}
function updateMe() {
  if (!meCard) return;
  const st = [];
  st.push(!micStream ? '只聽模式' : micOn ? '🎙️ 麥克風開' : '🔇 麥克風關');
  if (deaf) st.push('🙉 拒聽中');
  meCard.querySelector('.state').textContent = st.join(' · ');
}

function renderPeerCard(p) {
  const card = makeCard(p.info.name);
  p.card = card;
  const range = card.querySelector('.pvol'), out = card.querySelector('.pvolOut'), btn = card.querySelector('.pmute');
  range.value = p.vol; out.value = p.vol + '%';
  range.addEventListener('input', () => {
    p.vol = Number(range.value); out.value = p.vol + '%';
    store.set('vol:' + p.info.name, p.vol);
    if (p.vol > 0 && p.muted) { p.muted = false; }
    applyPeerGain(p); updatePeerCard(p);
  });
  btn.addEventListener('click', () => { p.muted = !p.muted; applyPeerGain(p); updatePeerCard(p); });
  $('#people').appendChild(card);
  updatePeerCard(p);
}

function updatePeerCard(p) {
  if (!p.card) return;
  const name = p.info.name || '…';
  p.card.querySelector('.name').textContent = name + (p.info.isHost ? ' 👑' : '');
  const av = p.card.querySelector('.avatar');
  av.textContent = [...name][0] || '?'; av.style.background = colorOf(name);
  const cs = p.pc.connectionState;
  const st = [];
  if (cs === 'connecting' || cs === 'new') st.push('連線中…');
  else if (cs === 'failed') st.push('⚠️ 連線失敗');
  else if (cs === 'disconnected') st.push('網路不穩…');
  st.push(p.info.mic ? '🎙️' : '🔇');
  if (p.info.deaf) st.push('🙉 拒聽中');
  if (p.muted) st.push('你已靜音他');
  p.card.querySelector('.state').textContent = st.join(' · ');
  p.card.querySelector('.pmute').textContent = p.muted ? '🔇' : '🔈';
  p.card.classList.toggle('muted-by-me', p.muted);
}

function applyPeerGain(p) {
  const v = deaf || p.muted ? 0 : p.vol / 100;
  p.gain.gain.setTargetAtTime(v, audioCtx.currentTime, 0.02);
}

function updateCount() { $('#count').textContent = (peers.size + 1) + ' 人'; }

// 誰正在說話（綠框）
function level(an) {
  const buf = new Uint8Array(an.fftSize); an.getByteTimeDomainData(buf);
  let s = 0; for (const v of buf) { const x = (v - 128) / 128; s += x * x; }
  return Math.sqrt(s / buf.length);
}
function speakingLoop() {
  if (meCard) meCard.classList.toggle('speaking', !!(micAnalyser && micOn && level(micAnalyser) > 0.03));
  for (const p of peers.values()) if (p.card) p.card.classList.toggle('speaking', !!p.source && level(p.analyser) > 0.03);
}

// ---------------------------------------------------------------------
//  底部控制：麥克風 / 拒聽 / 總音量
// ---------------------------------------------------------------------
$('#micBtn').addEventListener('click', () => {
  if (!micStream) return toast(window.isSecureContext ? '沒有麥克風權限，請在網址列允許後重新加入' : '非 https 連結無法使用麥克風');
  micOn = !micOn;
  micStream.getAudioTracks().forEach((t) => (t.enabled = micOn));
  updateControls(); postStatus();
});
$('#deafBtn').addEventListener('click', () => {
  deaf = !deaf;
  for (const p of peers.values()) applyPeerGain(p);
  applyScreenAudio();
  updateControls(); postStatus();
  toast(deaf ? '已拒聽：你聽不到任何人（別人仍聽得到你，除非你也關麥克風）' : '恢復聆聽');
});
$('#masterVol').addEventListener('input', (e) => {
  const v = Number(e.target.value);
  masterGain.gain.setTargetAtTime(v / 100, audioCtx.currentTime, 0.02);
  $('#masterVolOut').value = v + '%';
  store.set('masterVol', v);
});
function updateControls() {
  const mb = $('#micBtn');
  mb.classList.toggle('off', !micOn || !micStream);
  mb.innerHTML = (micOn && micStream ? '🎙️' : '🔇') + `<span>${!micStream ? '只聽' : micOn ? '麥克風開' : '麥克風關'}</span>`;
  const db = $('#deafBtn');
  db.classList.toggle('off', deaf);
  db.innerHTML = (deaf ? '🙉' : '🔊') + `<span>${deaf ? '拒聽中' : '聆聽中'}</span>`;
  updateMe();
}

// ---------------------------------------------------------------------
//  螢幕分享
// ---------------------------------------------------------------------
$('#shareBtn').addEventListener('click', () => (screenStream ? stopShare() : startShare()));

async function startShare() {
  try {
    screenStream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: { ideal: 30 } },
      audio: true, // Windows Chrome/Edge：勾選「分享系統音訊」就能讓大家聽到電腦的聲音
    });
  } catch { screenStream = null; return; }
  const vt = screenStream.getVideoTracks()[0];
  if (vt) { vt.contentHint = 'motion'; vt.onended = stopShare; }
  await api('/api/screen', { active: true, streamId: screenStream.id }).catch(() => { });
  for (const p of peers.values())
    screenStream.getTracks().forEach((t) => p.screenSenders.push(p.pc.addTrack(t, screenStream)));
  $('#shareBtn').textContent = '⏹ 停止分享';
  $('#shareBtn').classList.replace('primary', 'danger');
  const v = $('#screenVideo'); v.srcObject = screenStream; v.muted = true; // 自己預覽不放聲音，避免回音
  $('#screenTitle').textContent = '🖥️ 你正在分享螢幕';
  $('#screenBox').hidden = false;
  if (!screenStream.getAudioTracks().length) toast('提示：分享時勾選「分享音訊」，大家才聽得到電腦聲音', 5000);
}

async function stopShare() {
  if (!screenStream) return;
  for (const p of peers.values()) {
    for (const s of p.screenSenders) try { p.pc.removeTrack(s); } catch { }
    p.screenSenders = [];
  }
  screenStream.getTracks().forEach((t) => t.stop());
  screenStream = null;
  await api('/api/screen', { active: false }).catch(() => { });
  $('#shareBtn').textContent = '🖥️ 分享螢幕';
  $('#shareBtn').classList.replace('danger', 'primary');
  $('#screenVideo').srcObject = null;
  $('#screenBox').hidden = true;
}

function setScreenState(s) {
  screenState = s && s.active ? s : { active: false, streamId: null, hostId: null };
  if (screenStream) return; // 我自己就是分享者
  if (!screenState.active) {
    remoteScreenStream = null;
    $('#screenVideo').srcObject = null;
    $('#screenBox').hidden = true;
  } else {
    $('#screenTitle').textContent = '🖥️ 主辦方的螢幕';
    if (remoteScreenStream) $('#screenBox').hidden = false;
  }
}

function showRemoteScreen(stream) {
  remoteScreenStream = stream;
  const v = $('#screenVideo');
  if (v.srcObject !== stream) v.srcObject = stream;
  applyScreenAudio();
  v.play().catch(() => { });
  $('#screenBox').hidden = false;
  stream.onremovetrack = () => { if (!stream.getVideoTracks().length) setScreenState({ active: false }); };
}

function applyScreenAudio() {
  const v = $('#screenVideo');
  if (screenStream) { v.muted = true; return; }
  v.muted = deaf || !watching;
  v.volume = Number($('#screenVol').value) / 100;
}
$('#screenVol').addEventListener('input', applyScreenAudio);
function setWatching(w) {
  watching = w;
  $('#notWatching').hidden = w;
  $('#screenVideo').style.visibility = w ? 'visible' : 'hidden';
  $('#watchBtn').textContent = w ? '不看' : '觀看';
  applyScreenAudio();
}
$('#watchBtn').addEventListener('click', () => setWatching(!watching));
$('#watchBtn2').addEventListener('click', () => setWatching(true));
$('#fsBtn').addEventListener('click', () => {
  const v = $('#screenVideo');
  if (v.requestFullscreen) v.requestFullscreen().catch(() => { });
  else if (v.webkitEnterFullscreen) v.webkitEnterFullscreen();
});

// ---------------------------------------------------------------------
//  主辦方：連結 / 結束整個 App
// ---------------------------------------------------------------------
function setShareUrl(url) {
  if (url) { $('#shareUrl').value = url; return; }
  if (config && config.lanUrls && config.lanUrls.length) {
    $('#shareUrl').value = config.lanUrls[0];
    const n = $('#lanNote'); n.hidden = false;
    n.textContent = '⚠️ 沒有公開通道，只有同一個 Wi-Fi 能連，而且對方只能聽不能講（非 https）。請確認 cloudflared.exe 有下載成功。';
  }
  else if (config && config.noTunnel) {
    $('#shareUrl').value = '（沒有公開連結）';
    const n = $('#lanNote'); n.hidden = false;
    n.textContent = '⚠️ 找不到 runtime\\cloudflared.exe，朋友連不進來。請關掉後重新執行 start.bat 讓它下載。';
  }
}
$('#copyBtn').addEventListener('click', async () => {
  const v = $('#shareUrl').value;
  try { await navigator.clipboard.writeText(v); } catch { $('#shareUrl').select(); document.execCommand('copy'); }
  toast('已複製連結');
});
$('#endBtn').addEventListener('click', async () => {
  if (!confirm('確定要結束？所有人都會斷線，伺服器也會關閉。')) return;
  try { await api('/api/shutdown', {}); } catch { }
  endCall('你已經關閉了語音房，伺服器也停止了。現在可以關掉這個分頁。', true);
});

// ---------------------------------------------------------------------
//  離開 / 結束
// ---------------------------------------------------------------------
$('#leaveBtn').addEventListener('click', () => {
  sendLeave();
  endCall('你已離開通話。', false, '已離開');
});
let leaveSent = false;
function sendLeave() {
  if (leaveSent) return;
  leaveSent = true;
  const body = JSON.stringify({ k: roomKey, host: hostToken, from: myId });
  let ok = false;
  // text/plain 是所有瀏覽器都允許在關閉時送出的格式
  try { ok = !!navigator.sendBeacon && navigator.sendBeacon('/api/leave', new Blob([body], { type: 'text/plain' })); } catch { }
  if (!ok) try { fetch('/api/leave', { method: 'POST', body, keepalive: true, headers: { 'Content-Type': 'text/plain' } }); } catch { }
}
// 真的關掉分頁/離開網頁時才離開（只是切到別的分頁、縮小視窗，語音會繼續）
window.addEventListener('pagehide', () => { if (joined && !ended) sendLeave(); });
window.addEventListener('beforeunload', () => { if (joined && !ended) sendLeave(); });
// 從「上一頁」快取回來的頁面連線都斷了 → 重新整理
window.addEventListener('pageshow', (e) => { if (e.persisted && joined) location.reload(); });

function endCall(msg, hostEnded, title) {
  if (ended) return;
  ended = true;
  for (const id of [...peers.keys()]) removePeer(id);
  if (screenStream) screenStream.getTracks().forEach((t) => t.stop());
  if (micStream) micStream.getTracks().forEach((t) => t.stop());
  try { audioCtx && audioCtx.close(); } catch { }
  $('#roomView').hidden = true;
  $('#endedView').hidden = false;
  $('#endedTitle').textContent = title || '通話已結束';
  $('#endedMsg').textContent = msg;
  $('#rejoinBtn').hidden = !!hostEnded || !title;
}
$('#rejoinBtn').addEventListener('click', () => location.reload());

// ---------------------------------------------------------------------
//  背景保持：切到別的分頁/App 時盡量不中斷
// ---------------------------------------------------------------------
function checkAudioState() {
  if (!audioCtx || ended) return;
  $('#resumeBar').hidden = audioCtx.state === 'running';
}
$('#resumeBtn').addEventListener('click', () => audioCtx.resume().then(checkAudioState));
document.addEventListener('visibilitychange', () => {
  if (!document.hidden && audioCtx && audioCtx.state !== 'running') audioCtx.resume().then(checkAudioState).catch(checkAudioState);
});
function setupMediaSession() {
  if (!('mediaSession' in navigator)) return;
  try {
    navigator.mediaSession.metadata = new MediaMetadata({
      title: '語音房通話中', artist: myName,
      artwork: [{ src: 'icon-512.png', sizes: '512x512', type: 'image/png' }],
    });
  } catch { }
}

// ---------------------------------------------------------------------
//  安裝成 App（PWA）
// ---------------------------------------------------------------------
let installPrompt = null;
const isStandalone = matchMedia('(display-mode: standalone)').matches || navigator.standalone;
const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
if ('serviceWorker' in navigator && window.isSecureContext) navigator.serviceWorker.register('sw.js').catch(() => { });
window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); installPrompt = e; showInstall(); });
window.addEventListener('appinstalled', () => { document.querySelectorAll('.install').forEach((b) => (b.hidden = true)); toast('已安裝！'); });
function showInstall() { if (!isStandalone) document.querySelectorAll('.install').forEach((b) => (b.hidden = false)); }
if (isIOS && !isStandalone && window.isSecureContext) showInstall();
document.querySelectorAll('.install').forEach((b) => b.addEventListener('click', async () => {
  if (installPrompt) { installPrompt.prompt(); await installPrompt.userChoice; installPrompt = null; return; }
  if (isIOS) alert('iPhone / iPad：用 Safari 打開這個連結 → 點下方「分享」按鈕 → 「加入主畫面」');
  else alert('在瀏覽器選單（⋮）裡找「安裝應用程式」或「加到主畫面」');
}));

// ---------------------------------------------------------------------
let toastTimer;
function toast(msg, ms = 2500) {
  const t = $('#toast'); t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => (t.hidden = true), ms);
}
