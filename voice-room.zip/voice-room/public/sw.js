// 最小的 Service Worker：讓瀏覽器允許「安裝成 App」，通話本身一律走網路。
const CACHE = 'voice-room-v1';
const SHELL = ['./', 'index.html', 'style.css', 'app.js', 'icon-192.png', 'icon-512.png', 'manifest.webmanifest'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).catch(() => {}));
  self.skipWaiting();
});
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', (e) => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin) return;
  if (u.pathname.startsWith('/api') || u.pathname === '/events') return;
  // 網路優先，離線時才用快取
  e.respondWith(fetch(e.request).catch(() => caches.match(e.request, { ignoreSearch: true })));
});
