@echo off
chcp 65001 >nul
setlocal
title 語音房伺服器 - 關掉這個視窗也會結束
cd /d "%~dp0"

rem ============================================================
rem  全部東西都放在這個資料夾裡：
rem    runtime\node\        可攜式 Node.js（不安裝、不改 PATH）
rem    runtime\cloudflared.exe
rem    data\                房間鑰匙、專用瀏覽器設定檔
rem  不要了就把整個資料夾刪掉，電腦上不會留下任何東西。
rem ============================================================

set "RT=%~dp0runtime"
set "NODE=%RT%\node\node.exe"
set "CF=%RT%\cloudflared.exe"
set "FALLBACK_NODE=v22.12.0"
if not exist "%RT%" mkdir "%RT%"

if exist "%NODE%" goto havenode
echo [1/2] 第一次執行：下載可攜式 Node.js 到 runtime 資料夾（不會安裝到系統）...
set "NODEVER="
for /f "usebackq delims=" %%v in (`powershell -NoProfile -Command "try{[Net.ServicePointManager]::SecurityProtocol='Tls12'; ((Invoke-RestMethod 'https://nodejs.org/dist/index.json').Where({$_.lts},'First')).version}catch{}"`) do set "NODEVER=%%v"
if not defined NODEVER set "NODEVER=%FALLBACK_NODE%"
echo       版本 %NODEVER%
curl -L --fail -o "%RT%\node.zip" "https://nodejs.org/dist/%NODEVER%/node-%NODEVER%-win-x64.zip"
if errorlevel 1 goto failnode
tar -xf "%RT%\node.zip" -C "%RT%"
if errorlevel 1 goto failnode
if exist "%RT%\node" rmdir /s /q "%RT%\node"
ren "%RT%\node-%NODEVER%-win-x64" node
del /q "%RT%\node.zip"
if not exist "%NODE%" goto failnode
:havenode

if exist "%CF%" goto run
echo [2/2] 第一次執行：下載 cloudflared（產生 https 公開連結用，約 60MB）...
curl -L --fail -o "%CF%" "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
if errorlevel 1 goto failcf
goto run

:failcf
if exist "%CF%" del /q "%CF%"
echo.
echo 下載 cloudflared 失敗，朋友暫時連不進來。下次執行 start.bat 會再試一次。
echo.

:run
"%NODE%" "%~dp0server.js"
echo.
pause
exit /b

:failnode
if exist "%RT%\node.zip" del /q "%RT%\node.zip"
echo.
echo 下載 Node.js 失敗，請確認網路後再雙擊一次 start.bat。
pause
exit /b 1
