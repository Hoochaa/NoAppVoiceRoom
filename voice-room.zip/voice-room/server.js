// =====================================================================
//  語音房伺服器（只用 Node.js 內建模組，不需要 npm install）
//  啟動：雙擊 start.bat（或 node server.js）
// =====================================================================
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const { spawn, exec } = require('child_process');

// ------------------------- 設定 -------------------------
const CONFIG = {
  // 冷門 port（不在常見服務清單裡）。被占用的話改這裡。
  port: Number(process.env.PORT) || 41739,

  // true = 自動用 Cloudflare 免費通道產生 https 公開連結（不用設定路由器）
  useQuickTunnel: true,

  // false = 只接受本機連線（預設，不會跳 Windows 防火牆、不會新增任何系統規則）
  // true  = 沒有通道時開放同一個 Wi-Fi 連線（Windows 會跳防火牆詢問，會在系統留下規則）
  allowLan: false,

  // 如果你有「固定網址」（例如 Cloudflare 具名通道、Tailscale Funnel），填在這裡，
  // 例如 'https://voice.example.com'。填了就不會開免費通道。
  publicUrl: '',

  // 打洞用的 STUN 伺服器。如果有朋友（常見於手機 4G/5G）連得到但聽不到聲音，
  // 需要再加一個 TURN 伺服器，格式：
  // { urls: 'turn:你的turn伺服器:3478', username: 'xxx', credential: 'yyy' }
  iceServers: [
    { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
    { urls: 'stun:stun.cloudflare.com:3478' },
  ],
};
// -------------------------------------------------------

const PUBLIC_DIR = path.join(__dirname, 'public');
// 所有會產生的東西都放在專案資料夾裡，不碰系統
const RUNTIME_DIR = path.join(__dirname, 'runtime'); // 可攜式 Node.js、cloudflared
const DATA_DIR = path.join(__dirname, 'data');       // 房間鑰匙、專用瀏覽器設定檔
fs.mkdirSync(DATA_DIR, { recursive: true });
const HOST_TOKEN = crypto.randomBytes(16).toString('hex'); // 每次啟動都不同，只有主辦方知道

// 房間鑰匙存在檔案裡，重開也一樣 → 安裝成 App 後連結不會失效（搭配固定網址時）
const KEY_FILE = path.join(DATA_DIR, 'room-key.txt');
let ROOM_KEY;
try { ROOM_KEY = fs.readFileSync(KEY_FILE, 'utf8').trim(); } catch { }
if (!/^[a-f0-9]{12,}$/.test(ROOM_KEY || '')) {
  ROOM_KEY = crypto.randomBytes(8).toString('hex');
  try { fs.writeFileSync(KEY_FILE, ROOM_KEY); } catch { }
}

const clients = new Map(); // id -> { id, name, isHost, mic, deaf, queue, seq, poll, lastSeen }
const POLL_HOLD_MS = 10000;   // 長輪詢最多等多久
const GONE_MS = 8000;         // 多久沒來拿訊息就視為離開（正常情況每秒內就會再來）
let screen = { active: false, streamId: null, hostId: null };
let shareUrl = CONFIG.publicUrl ? CONFIG.publicUrl.replace(/\/$/, '') + '/?k=' + ROOM_KEY : null;
let tunnel = null;
let shuttingDown = false;

// ------------------------- 小工具 -------------------------
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml',
  '.webmanifest': 'application/manifest+json', '.json': 'application/json', '.ico': 'image/x-icon',
};

// ---- 訊息佇列 + 長輪詢（一般 HTTP 請求，任何通道/代理都不會卡住）----
function push(c, event, data) {
  c.queue.push({ seq: ++c.seq, event, data });
  if (c.queue.length > 3000) c.queue.splice(0, c.queue.length - 3000);
  flushPoll(c);
}
function flushPoll(c) {
  if (!c.poll) return;
  const events = c.queue.filter((e) => e.seq > c.poll.since);
  if (!events.length) return;
  const { res, timer } = c.poll;
  c.poll = null; clearTimeout(timer);
  c.lastSeen = Date.now();
  json(res, 200, { events });
}
function endPoll(c) {
  if (!c.poll) return;
  const { res, timer } = c.poll;
  c.poll = null; clearTimeout(timer);
  try { json(res, 200, { events: [] }); } catch { }
}
function broadcast(event, data, exceptId) {
  for (const c of clients.values()) if (c.id !== exceptId) push(c, event, data);
}
function publicInfo(c) {
  return { id: c.id, name: c.name, isHost: c.isHost, mic: c.mic, deaf: c.deaf };
}
function json(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}
function readBody(req) {
  return new Promise((resolve) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > 512 * 1024) { req.destroy(); resolve(null); } else chunks.push(c);
    });
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch { resolve(null); }
    });
    req.on('error', () => resolve(null));
  });
}
const isHostTok = (t) => typeof t === 'string' && t.length === HOST_TOKEN.length &&
  crypto.timingSafeEqual(Buffer.from(t), Buffer.from(HOST_TOKEN));
const authed = (k, host) => isHostTok(host) || k === ROOM_KEY;
const validId = (id) => typeof id === 'string' && /^[a-z0-9]{6,32}$/.test(id);
const cleanName = (n) => String(n || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 24) || '訪客';

function lanUrls() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces()))
    for (const a of list || []) if (a.family === 'IPv4' && !a.internal) out.push(`http://${a.address}:${CONFIG.port}/?k=${ROOM_KEY}`);
  return out;
}

function removeClient(id, reason) {
  const c = clients.get(id);
  if (!c) return;
  clients.delete(id);
  endPoll(c);
  broadcast('leave', { id, reason });
  if (screen.active && screen.hostId === id) {
    screen = { active: false, streamId: null, hostId: null };
    broadcast('screen', screen);
  }
}

// ------------------------- 路由 -------------------------
async function handle(req, res) {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  const q = url.searchParams;

  // ---- 設定（前端一開始會來拿）----
  if (p === '/api/config' && req.method === 'GET') {
    const host = q.get('host');
    if (!authed(q.get('k'), host)) return json(res, 403, { error: 'bad-link' });
    const isHost = isHostTok(host);
    return json(res, 200, {
      iceServers: CONFIG.iceServers,
      isHost,
      shareUrl: isHost ? shareUrl : undefined,
      lanUrls: isHost && CONFIG.allowLan ? lanUrls() : undefined,
      noTunnel: isHost && !cfExe && !CONFIG.publicUrl,
      roomKey: isHost ? ROOM_KEY : undefined,
    });
  }

  // ---- 加入（或重新加入）----
  if (p === '/api/join' && req.method === 'POST') {
    const b = await readBody(req);
    if (!b || !authed(b.k, b.host) || !validId(b.from)) return json(res, 403, {});
    let c = clients.get(b.from);
    const fresh = !c;
    if (!c) {
      c = { id: b.from, name: cleanName(b.name), isHost: isHostTok(b.host), mic: !!b.mic, deaf: false,
        queue: [], seq: 0, poll: null, lastSeen: Date.now() };
      clients.set(c.id, c);
    }
    c.lastSeen = Date.now();
    push(c, 'welcome', {
      fresh,
      you: publicInfo(c),
      peers: [...clients.values()].filter((x) => x.id !== c.id).map(publicInfo),
      screen,
      shareUrl: c.isHost ? shareUrl : undefined,
    });
    if (fresh) {
      broadcast('join', publicInfo(c), c.id);
      console.log(`[+] ${c.name}${c.isHost ? '（主辦）' : ''} 加入，目前 ${clients.size} 人`);
    }
    return json(res, 200, { ok: true });
  }

  // ---- 長輪詢：拿新訊息（沒有就等最多 25 秒）----
  if (p === '/api/poll' && req.method === 'GET') {
    if (!authed(q.get('k'), q.get('host'))) return json(res, 403, {});
    const c = clients.get(q.get('id'));
    if (!c) return json(res, 410, { error: 'gone' }); // 被判定離開 → 前端會自動重新加入
    const since = Number(q.get('since')) || 0;
    c.queue = c.queue.filter((e) => e.seq > since); // since 之前的已確認收到
    c.lastSeen = Date.now();
    c.probing = false;
    endPoll(c); // 同一個人舊的請求先結束
    c.poll = {
      res, since,
      timer: setTimeout(() => { if (c.poll && c.poll.res === res) { c.poll = null; c.lastSeen = Date.now(); json(res, 200, { events: [] }); } }, POLL_HOLD_MS),
    };
    res.on('close', () => { if (c.poll && c.poll.res === res) { clearTimeout(c.poll.timer); c.poll = null; } });
    flushPoll(c);
    return;
  }

  // ---- 轉送 WebRTC 協商訊息 ----
  if (p === '/api/signal' && req.method === 'POST') {
    const b = await readBody(req);
    if (!b || !authed(b.k, b.host) || !clients.has(b.from) || !Array.isArray(b.msgs)) return json(res, 403, {});
    for (const m of b.msgs.slice(0, 200)) {
      const to = clients.get(m && m.to);
      if (to) push(to, 'signal', { from: b.from, data: m.data });
    }
    return json(res, 200, { ok: true });
  }

  // ---- 狀態（麥克風開關／拒聽）----
  if (p === '/api/status' && req.method === 'POST') {
    const b = await readBody(req);
    const c = b && clients.get(b.from);
    if (!b || !authed(b.k, b.host) || !c) return json(res, 403, {});
    c.mic = !!b.mic; c.deaf = !!b.deaf;
    broadcast('status', publicInfo(c));
    return json(res, 200, { ok: true });
  }

  // ---- 螢幕分享狀態（只有主辦方）----
  if (p === '/api/screen' && req.method === 'POST') {
    const b = await readBody(req);
    if (!b || !isHostTok(b.host) || !clients.has(b.from)) return json(res, 403, {});
    screen = b.active
      ? { active: true, streamId: String(b.streamId || ''), hostId: b.from }
      : { active: false, streamId: null, hostId: null };
    broadcast('screen', screen);
    console.log(screen.active ? '[畫面] 主辦方開始分享螢幕' : '[畫面] 主辦方停止分享');
    return json(res, 200, { ok: true });
  }

  // ---- 離開（關閉分頁時的 sendBeacon）----
  if (p === '/api/leave' && req.method === 'POST') {
    const b = await readBody(req);
    if (b && authed(b.k, b.host) && clients.has(b.from)) {
      console.log(`[-] ${clients.get(b.from).name} 離開`);
      removeClient(b.from, 'left');
    }
    return json(res, 200, { ok: true });
  }

  // ---- 有人回報「我跟某人的語音連線斷了」→ 立刻確認對方還在不在 ----
  // 做法：把對方正在等的請求提早結束。活著的網頁會在 1 秒內再來；關掉的網頁不會 → 幾秒後移除
  if (p === '/api/peerlost' && req.method === 'POST') {
    const b = await readBody(req);
    if (!b || !authed(b.k, b.host) || !clients.has(b.from)) return json(res, 403, {});
    const t = clients.get(b.id);
    if (t && !t.probing) {
      t.probing = true;
      endPoll(t);
      t.lastSeen = Math.min(t.lastSeen, Date.now() - GONE_MS + 4000);
    }
    return json(res, 200, { ok: true });
  }

  // ---- 結束整個 App（只有主辦方）----
  if (p === '/api/shutdown' && req.method === 'POST') {
    const b = await readBody(req);
    if (!b || !isHostTok(b.host)) return json(res, 403, {});
    json(res, 200, { ok: true });
    shutdown('主辦方按下結束');
    return;
  }

  // ---- 靜態檔案 ----
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
  let rel = p === '/' ? '/index.html' : decodeURIComponent(p);
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
    });
    res.end(req.method === 'HEAD' ? undefined : data);
  });
}

const server = http.createServer((req, res) => {
  handle(req, res).catch((e) => { console.error(e); try { json(res, 500, {}); } catch { } });
});
server.keepAliveTimeout = 65000;
server.requestTimeout = 0;

// 太久沒來拿訊息的人（關掉網頁、斷網）→ 移除
setInterval(() => {
  const now = Date.now();
  for (const c of [...clients.values()]) {
    if (!c.poll && now - c.lastSeen > GONE_MS) { console.log(`[-] ${c.name} 斷線離開`); removeClient(c.id, 'timeout'); }
  }
}, 1000);

// ------------------------- Cloudflare 免費通道 -------------------------
function findCloudflared() {
  const local = path.join(RUNTIME_DIR, process.platform === 'win32' ? 'cloudflared.exe' : 'cloudflared');
  return fs.existsSync(local) ? local : null;
}

function startTunnel(exe) {
  console.log('正在建立公開 https 連結（Cloudflare 免費通道），約需 5~15 秒…');
  tunnel = spawn(exe, ['tunnel', '--no-autoupdate', '--url', `http://127.0.0.1:${CONFIG.port}`], {
    windowsHide: true,
    // 把 cloudflared 的「家目錄」指到專案資料夾，萬一它要寫設定也不會寫到你的使用者資料夾
    env: { ...process.env, USERPROFILE: path.join(DATA_DIR, 'cloudflared'), HOME: path.join(DATA_DIR, 'cloudflared') },
  });
  const onData = (d) => {
    const m = String(d).match(/https:\/\/[-a-z0-9]+\.trycloudflare\.com/);
    if (m && !shareUrl && !m[0].startsWith('https://api.')) {
      shareUrl = m[0] + '/?k=' + ROOM_KEY;
      console.log('\n==================================================');
      console.log(' 把這個連結傳給朋友：');
      console.log(' ' + shareUrl);
      console.log('==================================================\n');
      for (const c of clients.values()) if (c.isHost) push(c, 'shareurl', { shareUrl });
    }
  };
  tunnel.stdout.on('data', onData);
  tunnel.stderr.on('data', onData);
  tunnel.on('error', (e) => { console.log('無法啟動 cloudflared：' + e.message); tunnel = null; });
  tunnel.on('exit', (code) => { if (!shuttingDown) console.log('cloudflared 已結束（代碼 ' + code + '），公開連結失效。'); tunnel = null; });
}

// Windows：用 Edge「App 視窗模式」+ 專案內獨立設定檔打開，不碰你平常瀏覽器的資料
function findEdge() {
  if (process.platform !== 'win32') return null;
  const bases = [process.env['ProgramFiles(x86)'], process.env.ProgramFiles, process.env.LOCALAPPDATA].filter(Boolean);
  for (const b of bases) {
    const f = path.join(b, 'Microsoft', 'Edge', 'Application', 'msedge.exe');
    if (fs.existsSync(f)) return f;
  }
  return null;
}
function openBrowser(url) {
  const edge = findEdge();
  if (edge) {
    const prof = path.join(DATA_DIR, 'browser');
    spawn(edge, [`--app=${url}`, `--user-data-dir=${prof}`, '--no-first-run', '--no-default-browser-check',
      '--window-size=1100,850'], { detached: true, stdio: 'ignore' }).unref();
    return;
  }
  const cmd = process.platform === 'win32' ? `start "" "${url}"`
    : process.platform === 'darwin' ? `open "${url}"` : `xdg-open "${url}"`;
  exec(cmd, () => { });
}

function shutdown(reason) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log('\n正在關閉：' + reason);
  broadcast('ended', { reason });
  setTimeout(() => {
    try { tunnel && tunnel.kill(); } catch { }
    for (const c of clients.values()) endPoll(c);
    server.close();
    console.log('已全部關閉，可以關掉這個視窗了。');
    setTimeout(() => process.exit(0), 300);
  }, 600);
}
process.on('SIGINT', () => shutdown('Ctrl+C'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('exit', () => { try { tunnel && tunnel.kill(); } catch { } });

// ------------------------- 啟動 -------------------------
const cfExe = CONFIG.useQuickTunnel && !CONFIG.publicUrl ? findCloudflared() : null;
// 有通道 → 只聽本機（最安全，Windows 防火牆也不會跳視窗）；沒通道 → 開放區網
const bindHost = CONFIG.allowLan && !cfExe && !CONFIG.publicUrl ? '0.0.0.0' : '127.0.0.1';
if (CONFIG.publicUrl) console.log('使用固定網址：' + shareUrl);

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') console.log(`\nPort ${CONFIG.port} 已被占用（可能已經開著一個了）。請關掉舊的，或改 server.js 裡的 port。`);
  else console.log(e);
  process.exit(1);
});

server.listen(CONFIG.port, bindHost, () => {
  const hostUrl = `http://localhost:${CONFIG.port}/?host=${HOST_TOKEN}`;
  console.log(`語音房伺服器已啟動：port ${CONFIG.port}`);
  console.log('主辦方頁面（只給自己用，別外流）：' + hostUrl);
  if (cfExe) startTunnel(cfExe);
  else if (!CONFIG.publicUrl) {
    if (!CONFIG.allowLan) {
      console.log('\n找不到 runtime\\cloudflared.exe，朋友目前連不進來。請重新執行 start.bat 讓它下載。\n');
      return openBrowser(hostUrl);
    }
    console.log('\n找不到 cloudflared.exe → 只能在同一個 Wi-Fi/區網內使用：');
    lanUrls().forEach((u) => console.log('  ' + u));
    console.log('（注意：http 區網連結，朋友只能「聽」，瀏覽器不允許非 https 網頁用麥克風）\n');
  }
  openBrowser(hostUrl);
});
