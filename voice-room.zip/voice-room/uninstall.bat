@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 這會刪掉 runtime（Node.js、cloudflared）和 data（房間鑰匙、瀏覽器設定檔）。
echo 程式碼會保留，下次執行 start.bat 會重新下載。
echo 想完全移除：直接刪掉整個資料夾即可。
echo.
set /p ANS=確定要清除嗎？輸入 y 後按 Enter：
if /i not "%ANS%"=="y" exit /b
if exist runtime rmdir /s /q runtime
if exist data rmdir /s /q data
echo 已清除。
pause
